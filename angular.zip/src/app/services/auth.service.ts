import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor() { }
  data=sessionStorage.getItem('userData');
  userInfo=(this.data)?JSON.parse(this.data):null;

  loggedIn(){
    if(this.userInfo!=null){
      return true;
    }
    else
    return false;
  }
  
}
