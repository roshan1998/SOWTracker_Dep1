export interface MappingModel{
    soW_CandidateId: number,
    sowId: number,
    candidateId: number,
    statusId: number,
    type: string
  }