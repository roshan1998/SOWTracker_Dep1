export interface DellManagerModel{
    dellManagerId: number,
    dellManagerName: string,
    type: string
  }