export interface USTPOCModel{
    ustpocId: number,
    ustpocName: string,
    type: string
  }