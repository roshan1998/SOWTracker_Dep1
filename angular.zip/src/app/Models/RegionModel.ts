export interface RegionModel{
    regionId: number,
    region: string,
    type: string
  }