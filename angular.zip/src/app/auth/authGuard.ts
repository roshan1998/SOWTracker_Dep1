import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivate, Router } from "@angular/router";
import { CommonService } from "../common.service";
import { AuthService } from "../services/auth.service";

@Injectable()
export class AuthGuard implements CanActivate {
    
    constructor(private _authService: AuthService, private _router: Router,private commonServ:CommonService) { }

   
    canActivate(route: ActivatedRouteSnapshot): boolean {
        if (this._authService.loggedIn()) {
            console.log(route);          
            return this.checkforUserAccess(route);
        } else {
            this._router.navigate(['/login'])
            return false
        }
    }
    
    checkforUserAccess(_route: ActivatedRouteSnapshot) {
       let  data = sessionStorage.getItem('userData');
        let userInfo = (data) ? JSON.parse(data) : null;
        if(_route.routeConfig?.path?.toString()==='dashboard'){
            this.commonServ.loadComponent(true);
            return true;
        } 
        else{
            const screens = userInfo.ScreenNames.split(',');  
            console.log(screens);
            for(let ele in screens){
                if(screens[ele].toLowerCase()===_route.routeConfig?.path?.toString()){
                    console.log('login item');
                    this.commonServ.loadComponent(true);
                    return true;
                }
            }
        }   
        return false;
    }
}