﻿namespace CandidateSoW.Models
{
    public class USTPOCModel
    {
        public int USTPOCId { get; set; }
        public string USTPOCName { get; set; } = "";
        public string Type { get; set; } = "";
    }
}
