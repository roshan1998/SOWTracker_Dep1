﻿namespace CandidateSoW.Models
{
    public class DomainModel
    {
        public int DomainId { get; set; } = 0;
        public string DomainName { get; set; } = "";
        public string Type { get; set; } = "";
    }
}
